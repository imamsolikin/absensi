<!doctype html>
<html lang="en">

<head>
	<title>Sisfo Ekstrakurikuler SMAN 1 Tempuran Karawang</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
   <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css');?>">
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/main.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.dataTables.min.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery-ui.theme.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/select2.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/toastr.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.timepicker.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/dropzone.css');?>">

	<link rel=" icon" href="<?php echo base_url('assets/img/images.jpeg');?>">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<style>
    .act-btn{
            background:green;
            display: block;
            width: 50px;
            height: 50px;
            line-height: 50px;
            text-align: center;
            color: white;
            font-size: 30px;
            font-weight: bold;
            border-radius: 50%;
            -webkit-border-radius: 50%;
            text-decoration: none;
            transition: ease all 0.3s;
            position: fixed;
            right: 30px;
            bottom:30px;
	    z-index:100;
        }
    .act-btn:hover{background: blue}
    </style>
</head>

<body>