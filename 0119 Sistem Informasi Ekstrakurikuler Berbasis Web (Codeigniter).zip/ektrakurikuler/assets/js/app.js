$(document).ready(function(){
    
    $("#set_kegiatan").select2();
    $("#set_partisipan").select2();
});